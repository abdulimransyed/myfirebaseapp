package syedabdul.mobile.myfirebaseapp

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Assuming you are inside an AppCompatActivity or a class that extends AppCompatActivity

        // Get reference to the support ActionBar
        val actionBar = supportActionBar

        // Set the title for the ActionBar
        actionBar?.title = "Firebase App"

        // Initialize Firebase Authentication
        auth = Firebase.auth

        // Login button click listener
        val buttonLogin: Button = findViewById(R.id.button_login)
        buttonLogin.setOnClickListener {
            // Handle button click event here
            // This block of code will be executed when the button is clicked
            val loginIntent = Intent(this, FirstFragment::class.java) // Replace LoginActivity with your actual login activity class
            startActivity(loginIntent)
        }

        // Register button click listener
        val buttonR: Button = findViewById(R.id.button_register)
        buttonR.setOnClickListener {
            // Handle button click event here
            // This block of code will be executed when the button is clicked
            val registerIntent = Intent(this, SecondFragment::class.java) // Replace RegisterActivity with your actual registration activity class
            startActivity(registerIntent)

            // Write a message to the database
            if (auth.currentUser != null) {
                // Check if user is authenticated
                val database = Firebase.database
                val myRef = database.getReference("message")

                myRef.setValue("Hello, Prof Yash!")

                // Read from the database
                myRef.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        // This method is called once with the initial value and again
                        // whenever data at this location is updated.
                        val value = dataSnapshot.getValue<String>()
                        Log.d(TAG, "Value is: $value")
                    }

                    override fun onCancelled(error: DatabaseError) {
                        // Failed to read value
                        Log.w(TAG, "Failed to read value.", error.toException())
                    }
                })
            }
        }
    }
}
