package syedabdul.mobile.myfirebaseapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity


class RegisterActivity : AppCompatActivity() {


    private lateinit var editTextFullName: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPhone: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var editTextDob: EditText
    private lateinit var editTextConfirmPassword: EditText
    private lateinit var editTextGender: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var radioGroup: RadioGroup
    private lateinit var radioGroupGender: RadioGroup


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Initialize the EditText variables
        editTextFullName = findViewById(R.id.edittext_register_full_name)
        editTextEmail = findViewById(R.id.edittext_register_email)
        editTextPhone = findViewById(R.id.edittext_register_mobile)
        editTextPassword = findViewById(R.id.edittext_register_password)
        editTextDob = findViewById(R.id.edittext_register_dob)
        editTextConfirmPassword = findViewById(R.id.edittext_register_confirm_password)
        editTextGender = findViewById(R.id.edittext_register_gender)
        progressBar = findViewById(R.id.progressbar)
        radioGroup = findViewById(R.id.radio_female)
        radioGroup = findViewById(R.id.radio_male)

        // Initialize the RadioGroup
        radioGroupGender = findViewById(R.id.button_register)

        // Set a checked change listener for the RadioGroup
        radioGroupGender.setOnCheckedChangeListener { _, checkedId ->
            // Find the checked radio button
            val radioButton = findViewById<RadioButton>(checkedId)

            // Get the text of the checked radio button
            radioButton.text.toString()


        }

        // You can now use these EditText variables to reference the EditText views in your code
        // For example, you can set text, get text, set listeners, etc.
        editTextFullName.setText("John Doe")
        editTextEmail.setText("johndoe@example.com")
        editTextPhone.setText("1234567890")
        editTextPassword.setText("myPassword")
        editTextGender.setText("male/female")
        progressBar.progress = 50

        supportActionBar?.title = "register"


    }
}
