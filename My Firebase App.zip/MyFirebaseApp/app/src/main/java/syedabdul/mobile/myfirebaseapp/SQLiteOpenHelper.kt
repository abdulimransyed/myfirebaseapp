package syedabdul.mobile.myfirebaseapp

    import android.annotation.SuppressLint
    import android.content.Context
    import android.database.sqlite.SQLiteDatabase
    import android.database.sqlite.SQLiteOpenHelper
    import android.content.ContentValues
    import android.database.Cursor

class DatabaseManager(context: Context) {

    private val dbHelper = syedabdul.mobile.myfirebaseapp.SQLiteOpenHelper.DatabaseHelper(context)
    private val db = dbHelper.writableDatabase

    // Create
    fun addUser(name: String, email: String) {
        val values = ContentValues().apply {
            put("name", name)
            put("email", email)
        }
        db.insert("users", null, values)
    }

    // Read
    @SuppressLint("Range")
    fun getUsers(): List<User> {
        val users = mutableListOf<User>()
        val cursor: Cursor = db.rawQuery("SELECT * FROM users", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndex("id"))
                val name = cursor.getString(cursor.getColumnIndex("name"))
                val email = cursor.getString(cursor.getColumnIndex("email"))
                val user = User(id, name, email)
                users.add(user)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return users
    }

    // Update
    fun updateUser(id: Int, name: String, email: String) {
        val values = ContentValues().apply {
            put("name", name)
            put("email", email)
        }
        db.update("users", values, "id = ?", arrayOf(id.toString()))
    }

    // Delete
    fun deleteUser(id: Int) {
        db.delete("users", "id = ?", arrayOf(id.toString()))
    }

    data class User(val id: Int, val name: String, val email: String)
}


class SQLiteOpenHelper {


    class DatabaseHelper(context: Context) :
        SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

        companion object {
            private const val DATABASE_NAME = "myfirebaseapp"
            private const val DATABASE_VERSION = 1
        }

        override fun onCreate(db: SQLiteDatabase) {
            // Create your database tables here
            // For example:
            db.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            // Handle database upgrade here
        }
    }


}