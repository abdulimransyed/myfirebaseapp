import android.util.Log as AndroidLog
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

import android.util.Log

// Define a logging tag
private const val TAG = "FirebaseExample"


// Create a data class to represent the watch details
data class Watch(val brand: String, val name: String, val category: String, val cost: Int)

fun writeToDatabase() {
    // Create a Firebase Realtime Database reference
    val database = FirebaseDatabase.getInstance().reference

    // Create a new watch object
    val watch = Watch("Rolex", "Submariner", "Diving", 8000)

    // Generate a unique key for the watch item
    val watchKey = database.child("watches").push().key

    // Write the watch data to the database using the generated key
    if (watchKey != null) {
        // Use the watchKey as the child key under "watches" node
        database.child("watches").child(watchKey).setValue(watch)
            .addOnSuccessListener {
                println("Watch data is successfully written to the database with key: $watchKey")
            }
            .addOnFailureListener { exception ->
                println("Failed to write watch data to the database: ${exception.message}")
            }
    }
}

fun readFromDatabase() {
    // Create a Firebase Realtime Database reference
    val database = FirebaseDatabase.getInstance().reference

    // Create a ValueEventListener to read data from the database
    val valueEventListener = object : ValueEventListener {
        override fun onDataChange(dataSnapshot: DataSnapshot) {
            // This method is called once with the initial value and again
            // whenever data at this location is updated.
            val value = dataSnapshot.getValue(String::class.java)
            Log.d(TAG, "Value is: $value")
        }

        override fun onCancelled(databaseError: DatabaseError) {
            // Failed to read value
            Log.w(TAG, "Failed to read value.", databaseError.toException())
        }
    }

    // Attach the ValueEventListener to the database reference
    database.child("https://my-firebase-app-b2bb1-default-rtdb.firebaseio.com/").addValueEventListener(valueEventListener)
}

